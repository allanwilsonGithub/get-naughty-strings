"""An example of package
    A sharable python library to allow Robot Framework tests to retrieve Naughty Strings as an array for use in manual
    or autotesting of input fields or other forms.
"""

__version__ = '0.0.1'
__author__ = 'Allan Wilson'
